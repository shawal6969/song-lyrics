# hard-rock-solution
api link: https://api.lyrics.ovh/suggest/summer
